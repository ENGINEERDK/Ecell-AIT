<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IdeaSubmission extends Model
{
    //
}
